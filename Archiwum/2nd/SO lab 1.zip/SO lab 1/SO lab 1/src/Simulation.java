import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class Simulation {

    public static void main(String[] args) {

        // IF YOU WANNA TEST OUT THE RANDOMLY GENERATED LIST, JUST UN-COMMENT THE CODE BELOW

       /*ArrayList<Process> lista = generateProcessList();
       System.out.println("Poczatkowa lista procesow: \n");
       printList(lista);

       ArrayList<Process> sortedList = sortList(lista);

        runFCFS(sortedList);
        runSJF(sortedList);
        runSRTF(sortedList);
        runRR(sortedList, 30);*/

        ArrayList<Process> listaTest = new ArrayList<Process>();
        listaTest.add(new Process(1, 0, 5));
        listaTest.add(new Process(2, 0, 3));
        listaTest.add(new Process(3, 1, 1));
        listaTest.add(new Process(4, 2, 2));

        ArrayList<Process> sortedListaTest = sortList(listaTest);

        runFCFS(sortedListaTest);
        runSJF(sortedListaTest);
        runSRTF(sortedListaTest);
        runRR(sortedListaTest, 3);


    }

    public static ArrayList<Process> generateProcessList() {                           //as in method name
        int randomAT;
        int randomBT;
        ArrayList<Process> list = new ArrayList<Process>();                                         // arrival time, burst time and process list

        for (int i = 0; i < 500; i++) {
            randomAT = ThreadLocalRandom.current().nextInt(0, 100);     //set arrival time to value from 0 to [max - 1]
            randomBT = ThreadLocalRandom.current().nextInt(1, 30);          //set burst time to value from 1 to [max - 1]
            list.add(new Process(i + 1, randomAT, randomBT));                                         // add fresh process to the list
        }
        return list;
    }

    public static void printList(ArrayList<Process> list) {
        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i).toString());
        }
        System.out.println("========================");
    }

    public static void runFCFS(ArrayList<Process> list) {
        calculateWTs(list);
    }
    public static void runSJF(ArrayList<Process> list){
        calculateWTsSJF(list);
    }
    public static void runSRTF(ArrayList<Process> list){
        calculateWTsSRTF(list);
    }
    public static void runRR(ArrayList<Process> list, int quant){
        calculateWTsRR(list, quant);
    }

    public static ArrayList<Process> sortList(ArrayList<Process> list) {

        ArrayList<Process> temp = new ArrayList<Process>();                                     // spare process list

        for (int i = 0; i < list.size(); i++) {
            temp.add(list.get(i));                                                                           //copy contents of the original list
        }


        for (int i = 0; i < temp.size() - 1; i++) {
            for (int j = 0; j < temp.size() - 1 - i; j++) {
                if (temp.get(j).getArrival_time() > temp.get(j + 1).getArrival_time()) {
                    Process tempProc = temp.get(j);
                    temp.set(j, temp.get(j +1));
                    temp.set(j+1, tempProc);
                }
            }
        }
        System.out.println("Posortowana lista procesow: \n");
        printList(temp);
        return temp;
    }

    public static ArrayList<Process> copyList(ArrayList<Process> list){
        ArrayList<Process> temp = new ArrayList<Process>();                                     // spare process list

        for (int i = 0; i < list.size(); i++) {
            Process proc = new Process(list.get(i).getId(), list.get(i).getArrival_time(), list.get(i).getBurst_time());                //deep copy contents of the original list
            temp.add(proc);
        }
        return temp;
    }




    public static void calculateWTs(ArrayList<Process> list){
        int suma_czas = list.get(0).getArrival_time();
        double averageWT;
        double totalWT = 0;
        double size = list.size();
        for(int i = 0; i < size; i++){
            Process proc = list.get(i);
            if(proc.getArrival_time() <= suma_czas)
            totalWT +=  suma_czas - proc.getArrival_time();
            else totalWT += 0;
            suma_czas +=  proc.getBurst_time();
        }
        averageWT = totalWT/size;

        System.out.println("Algorytm FCFS:\nCałkowity czas oczekiwania: " + totalWT + "ms"
                + "\nSredni czas oczekiwania: " + averageWT + "ms\n");
    }

    public static void calculateWTsSJF(ArrayList<Process> list){
        ArrayList<Process> temporalList = copyList(list);
       int suma_czas = temporalList.get(0).getArrival_time();
       double averageWT;
       double totalWT = 0;
       double size = temporalList.size();
       while(!temporalList.isEmpty()) {
            Process proc = find_shortestSJF(temporalList, suma_czas);
            if(proc.getArrival_time() <= suma_czas)
                totalWT +=  suma_czas - proc.getArrival_time();
            else totalWT += 0;
            suma_czas +=  proc.getBurst_time();
            temporalList.remove(proc);
        }
        averageWT = totalWT/size;
        System.out.println("Algorytm SJF bez wywlaszczenia: \nCałkowity czas oczekiwania: " + totalWT + "ms"
                + "\nSredni czas oczekiwania: " + averageWT + "ms\n");
    }

    public static Process find_shortestSJF (ArrayList<Process> list, int time) {

        Process proc1= list.get(0);
        for(int i=1; i<list.size(); i++)
        {
            if(list.get(i).getArrival_time() <= time) {
                if( proc1.getBurst_time() > list.get(i).getBurst_time()) {
                    proc1 = list.get(i);
                }
            }
        }
        return proc1;
    }

    public static void calculateWTsSRTF(ArrayList<Process> list){
        ArrayList<Process> temporalList = copyList(list);
        int suma_czas = temporalList.get(0).getArrival_time();
        double averageWT;
        double totalWT = 0;
        double size = temporalList.size();
        while(!temporalList.isEmpty()) {
            Process proc1 = find_shortestSRTF(temporalList, suma_czas);
            proc1.setRemaining_burst_time(proc1.getRemaining_burst_time() - 1);
            suma_czas++;
            if(proc1.getRemaining_burst_time() == 0) {
                if(proc1.getArrival_time() <= suma_czas)
                    totalWT += suma_czas - proc1.getBurst_time() - proc1.getArrival_time();
                else totalWT += 0;
                temporalList.remove(proc1);
            }
        }
        averageWT = totalWT/size;
        System.out.println("Algorytm SRTF (SJF z wywłaszczaniem): \nCałkowity czas oczekiwania: " + totalWT + "ms"
                + "\nSredni czas oczekiwania: " + averageWT + "ms\n");


    }

    public static Process find_shortestSRTF(ArrayList<Process> list, int time) {

        Process proc = list.get(0);
        for(int i=1; i < list.size(); i++)
        {
            if( list.get(i).getArrival_time() <= time){
                if( proc.getRemaining_burst_time() > list.get(i).getRemaining_burst_time()) {
                    proc = list.get(i);
                }
            }
        }
        return proc;
    }

    public static void calculateWTsRR(ArrayList<Process> list, int quant){
        ArrayList<Process> processList = copyList(list);
        ArrayList<Process> processQueue = new ArrayList<Process>();
        int quantum = quant;
        int current_time = 0;
        double averageWT;
        double totalWT = 0;
        double size = processList.size();


        while(!(processList.isEmpty() && processQueue.isEmpty())){
            for (int i = 0; i < processList.size(); i++){
                if(processList.get(i).getArrival_time() <= current_time){
                    processQueue.add(0, processList.get(i));
                    processList.remove(i);
                    i = processList.size();
                } else {
                    current_time++;
                    i--;
                }
            }

            if(processQueue.get(0).getRemaining_burst_time() > quantum){
                current_time += quantum;
                Process currentProcess = processQueue.get(0);
                processQueue.remove(0);
                currentProcess.setRemaining_burst_time(currentProcess.getRemaining_burst_time() - quantum);
                processQueue.add(currentProcess);
            } else if (processQueue.get(0).getRemaining_burst_time() == quantum){
                current_time += quantum;
                totalWT += current_time - processQueue.get(0).getArrival_time() - processQueue.get(0).getBurst_time();
                processQueue.remove(0);
            } else {
                current_time += processQueue.get(0).getRemaining_burst_time();
                totalWT += current_time - processQueue.get(0).getArrival_time() - processQueue.get(0).getBurst_time();
                processQueue.remove(0);

            }
        }
        averageWT = totalWT/size;
        System.out.println("Algorytm RR: \nCałkowity czas oczekiwania: " + totalWT + "ms"
                + "\nSredni czas oczekiwania: " + averageWT + "ms\n");



    }
  }

